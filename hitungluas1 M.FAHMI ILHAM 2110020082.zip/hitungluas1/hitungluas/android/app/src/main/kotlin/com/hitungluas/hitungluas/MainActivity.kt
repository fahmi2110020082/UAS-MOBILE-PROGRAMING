package com.hitungluas.hitungluas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
